﻿using UnityEngine;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Compilation;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json;

namespace UnitySkills
{
    /// <summary>
    /// Debug skills: self-healing, proactive error checks, compile control.
    /// </summary>
    public static class DebugSkills
    {
        internal sealed class LogEntryInfo
        {
            public string type;
            public string message;
            public string file;
            public int line;
        }

        // Snapshot value of the Scripting Define Symbols. The build target group must be recorded
        // alongside it, so that undo/redo still applies to the correct group even if the active
        // build target was switched in the meantime.
        private sealed class DefinesSettingValue
        {
            public string group;
            public string defines;
        }

        /// <summary>
        /// Registers the Scripting Define restorer, so debug_set_defines changes can be rolled
        /// back through workflow undo/redo. Runs on domain load.
        /// </summary>
        [InitializeOnLoadMethod]
        private static void RegisterSettingRestorers()
        {
            WorkflowSettingRestorerRegistry.Register("debug.scriptingDefines",
                CaptureDefinesValue,
                ApplyDefinesValue);
        }

        private static string CaptureDefinesValue()
        {
            var group = EditorUserBuildSettings.selectedBuildTargetGroup;
            string defines;
            try
            {
                defines = PlayerSettings.GetScriptingDefineSymbols(NamedBuildTarget.FromBuildTargetGroup(group)) ?? string.Empty;
            }
            catch (System.Exception ex)
            {
                SkillsLogger.LogWarning($"[DebugSkills] Failed to capture defines for {group}: {ex.Message}");
                defines = string.Empty;
            }
            return JsonConvert.SerializeObject(new DefinesSettingValue
            {
                group = group.ToString(),
                defines = defines
            });
        }

        private static bool ApplyDefinesValue(string json)
        {
            if (string.IsNullOrEmpty(json))
                return false;

            var value = JsonConvert.DeserializeObject<DefinesSettingValue>(json);
            if (value == null || string.IsNullOrEmpty(value.group))
                return false;

            if (!System.Enum.TryParse(value.group, out BuildTargetGroup group))
                return false;

            try
            {
                PlayerSettings.SetScriptingDefineSymbols(NamedBuildTarget.FromBuildTargetGroup(group), value.defines ?? string.Empty);
                return true;
            }
            catch (System.Exception ex)
            {
                SkillsLogger.LogWarning($"[DebugSkills] Failed to apply defines for {group}: {ex.Message}");
                return false;
            }
        }

        // Unity LogEntry mode bits, values taken from UnityCsReference.
        private const int ModeError = 1;
        private const int ModeAssert = 2;
        private const int ModeLog = 4;
        private const int ModeFatal = 16;
        private const int ModeAssetImportError = 64;
        private const int ModeAssetImportWarning = 128;
        private const int ModeScriptingError = 256;
        private const int ModeScriptingWarning = 512;
        private const int ModeScriptingLog = 1024;
        private const int ModeScriptCompileError = 2048;
        private const int ModeScriptCompileWarning = 4096;
        private const int ModeScriptingException = 131072;

        internal const int ErrorModeMask = ModeError | ModeAssert | ModeFatal | ModeAssetImportError | ModeScriptingError | ModeScriptCompileError | ModeScriptingException;
        internal const int WarningModeMask = ModeAssetImportWarning | ModeScriptingWarning | ModeScriptCompileWarning;
        internal const int LogModeMask = ModeLog | ModeScriptingLog;

        // Reflection member cache: initialized on first use, cleared on failure so the next attempt can retry.
        private static System.Type _logEntriesType;
        private static System.Type _logEntryType;
        private static MethodInfo _getCountMethod;
        private static MethodInfo _getEntryMethod;
        private static MethodInfo _startMethod;
        private static MethodInfo _endMethod;
        private static FieldInfo _modeField;
        private static FieldInfo _messageField;
        private static FieldInfo _fileField;
        private static FieldInfo _lineField;

        internal static bool EnsureReflection()
        {
            if (_getEntryMethod != null) return true;

            var asm = System.Reflection.Assembly.GetAssembly(typeof(SceneView));
            _logEntriesType = asm?.GetType("UnityEditor.LogEntries");
            _logEntryType = asm?.GetType("UnityEditor.LogEntry");

            if (_logEntriesType == null || _logEntryType == null)
            {
                SkillsLogger.LogError("DebugSkills: UnityEditor.LogEntries or LogEntry type not found.");
                return false;
            }

            var staticFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
            _getCountMethod = _logEntriesType.GetMethod("GetCount", staticFlags);
            _getEntryMethod = _logEntriesType.GetMethod("GetEntryInternal", staticFlags);
            _startMethod = _logEntriesType.GetMethod("StartGettingEntries", staticFlags);
            _endMethod = _logEntriesType.GetMethod("EndGettingEntries", staticFlags);

            var instFlags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            _modeField = _logEntryType.GetField("mode", instFlags);
            _messageField = _logEntryType.GetField("message", instFlags);
            _fileField = _logEntryType.GetField("file", instFlags);
            _lineField = _logEntryType.GetField("line", instFlags);

            bool ok = _getCountMethod != null && _getEntryMethod != null &&
                      _startMethod != null && _endMethod != null &&
                      _modeField != null && _messageField != null &&
                      _fileField != null && _lineField != null;

            if (!ok)
            {
                SkillsLogger.LogError("DebugSkills: Failed to reflect required members of LogEntries/LogEntry.");
                _logEntriesType = null;
                _logEntryType = null;
                _getCountMethod = null;
                _getEntryMethod = null;
                _startMethod = null;
                _endMethod = null;
                _modeField = null;
                _messageField = null;
                _fileField = null;
                _lineField = null;
            }

            return ok;
        }

        internal static List<LogEntryInfo> ReadLogEntries(int targetMask, string filter, int limit)
        {
            var results = new List<LogEntryInfo>();
            if (!EnsureReflection()) return results;

            var entry = System.Activator.CreateInstance(_logEntryType);
            _startMethod.Invoke(null, null);
            try
            {
                int count = (int)_getCountMethod.Invoke(null, null);
                int found = 0;
                for (int i = count - 1; i >= 0 && found < limit; i--)
                {
                    _getEntryMethod.Invoke(null, new object[] { i, entry });
                    int mode = (int)_modeField.GetValue(entry);
                    if ((mode & targetMask) == 0) continue;

                    string msg = (string)_messageField.GetValue(entry) ?? "";
                    if (!string.IsNullOrEmpty(filter) && !msg.Contains(filter)) continue;

                    string file = (string)_fileField.GetValue(entry) ?? "";
                    int line = (int)_lineField.GetValue(entry);

                    string logType = (mode & ErrorModeMask) != 0 ? "Error"
                                   : (mode & WarningModeMask) != 0 ? "Warning"
                                   : "Log";

                    results.Add(new LogEntryInfo
                    {
                        type = logType,
                        message = msg.Length > 500 ? msg.Substring(0, 500) + "..." : msg,
                        file = file,
                        line = line
                    });
                    found++;
                }
            }
            finally
            {
                _endMethod.Invoke(null, null);
            }

            return results;
        }

        [UnitySkill("debug_get_errors", "Get only errors and exceptions from Unity Console logs. Reads existing console history directly (no setup needed). For all log types use console_get_logs.",
            Category = SkillCategory.Debug, Operation = SkillOperation.Query,
            Tags = new[] { "errors", "console", "logs", "exceptions" },
            Outputs = new[] { "count", "logs" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object DebugGetErrors(int limit = 50) => DebugGetLogs("Error", null, limit);

        [UnitySkill("debug_get_logs", "Get console logs filtered by type (Error/Warning/Log) and content. Reads existing console history directly (no setup needed). Prefer console_get_logs for all-type queries with timestamp support.",
            Category = SkillCategory.Debug, Operation = SkillOperation.Query,
            Tags = new[] { "logs", "console", "filter", "warning", "error" },
            Outputs = new[] { "count", "logs" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object DebugGetLogs(string type = "Error", string filter = null, int limit = 50)
        {
            int targetMask = 0;
            if (type.Contains("Error")) targetMask |= ErrorModeMask;
            if (type.Contains("Warning")) targetMask |= WarningModeMask;
            if (type.Contains("Log")) targetMask |= LogModeMask;
            if (targetMask == 0) targetMask = ErrorModeMask;

            var results = ReadLogEntries(targetMask, filter, limit);
            return new { count = results.Count, logs = results };
        }

        [UnitySkill("debug_check_compilation", "Check if Unity is currently compiling scripts.",
            Category = SkillCategory.Debug, Operation = SkillOperation.Query,
            Tags = new[] { "compilation", "compiling", "status", "check" },
            Outputs = new[] { "isCompiling", "isUpdating" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object DebugCheckCompilation()
        {
            return new
            {
                isCompiling = EditorApplication.isCompiling,
                isUpdating = EditorApplication.isUpdating
            };
        }

        [UnitySkill("debug_force_recompile", "Force script recompilation.",
            Category = SkillCategory.Debug, Operation = SkillOperation.Execute,
            Tags = new[] { "recompile", "refresh", "scripts", "compilation" },
            Outputs = new[] { "message" },
            MayTriggerReload = true)]
        public static object DebugForceRecompile()
        {
            AssetDatabase.Refresh();
            CompilationPipeline.RequestScriptCompilation();

            return new
            {
                success = true,
                message = "Compilation requested",
                serverAvailability = ServerAvailabilityHelper.CreateTransientUnavailableNotice(
                    "Compilation was requested manually. The REST server may be briefly unavailable while Unity reloads assemblies.",
                    alwaysInclude: true)
            };
        }

        [UnitySkill("debug_get_system_info", "Get Editor and System capabilities.",
            Category = SkillCategory.Debug, Operation = SkillOperation.Query,
            Tags = new[] { "system", "info", "hardware", "unity-version" },
            Outputs = new[] { "unityVersion", "platform", "processorType", "systemMemorySize", "graphicsDeviceName" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object DebugGetSystemInfo()
        {
            return new
            {
                unityVersion = Application.unityVersion,
                platform = Application.platform.ToString(),
                deviceModel = SystemInfo.deviceModel,
                processorType = SystemInfo.processorType,
                systemMemorySize = SystemInfo.systemMemorySize,
                graphicsDeviceName = SystemInfo.graphicsDeviceName,
                graphicsMemorySize = SystemInfo.graphicsMemorySize,
                editorSkin = EditorGUIUtility.isProSkin ? "Dark" : "Light"
            };
        }

        [UnitySkill("debug_get_stack_trace", "Get stack trace for a log entry by index",
            Category = SkillCategory.Debug, Operation = SkillOperation.Query,
            Tags = new[] { "stack-trace", "log", "debug", "entry" },
            Outputs = new[] { "index", "message", "stackTrace" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object DebugGetStackTrace(int entryIndex)
        {
            if (!EnsureReflection())
                return new { error = "Reflection initialization failed" };

            var entry = System.Activator.CreateInstance(_logEntryType);
            _startMethod.Invoke(null, null);
            try
            {
                int count = (int)_getCountMethod.Invoke(null, null);
                if (entryIndex < 0 || entryIndex >= count)
                    return new { error = $"Index {entryIndex} out of range (0-{count - 1})" };

                _getEntryMethod.Invoke(null, new object[] { entryIndex, entry });
                var msg = (string)_messageField.GetValue(entry) ?? "";
                var lines = msg.Split('\n');
                return new { index = entryIndex, message = lines[0], stackTrace = string.Join("\n", lines.Skip(1)) };
            }
            finally
            {
                _endMethod.Invoke(null, null);
            }
        }

        [UnitySkill("debug_get_assembly_info", "Get project assembly information",
            Category = SkillCategory.Debug, Operation = SkillOperation.Query,
            Tags = new[] { "assembly", "project", "compilation", "info" },
            Outputs = new[] { "count", "assemblies" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object DebugGetAssemblyInfo()
        {
            var assemblies = CompilationPipeline.GetAssemblies(AssembliesType.Player)
                .Select(a => new { name = a.name, sourceFiles = a.sourceFiles.Length, defines = a.defines.Length })
                .ToArray();
            return new { success = true, count = assemblies.Length, assemblies };
        }

        [UnitySkill("debug_get_defines", "Get scripting define symbols for current platform",
            Category = SkillCategory.Debug, Operation = SkillOperation.Query,
            Tags = new[] { "defines", "symbols", "preprocessor", "platform" },
            Outputs = new[] { "buildTargetGroup", "defines" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object DebugGetDefines()
        {
            var group = EditorUserBuildSettings.selectedBuildTargetGroup;
            try
            {
                var defines = PlayerSettings.GetScriptingDefineSymbols(NamedBuildTarget.FromBuildTargetGroup(group));
                return new { success = true, buildTargetGroup = group.ToString(), defines };
            }
            catch (System.Exception ex)
            {
                return new
                {
                    success = false,
                    error = $"Failed to read scripting define symbols for {group}: {ex.Message}",
                    buildTargetGroup = group.ToString()
                };
            }
        }

        [UnitySkill("debug_set_defines", "Set scripting define symbols for current platform", TracksWorkflow = true,
            Category = SkillCategory.Debug, Operation = SkillOperation.Modify,
            Tags = new[] { "defines", "symbols", "preprocessor", "set" },
            Outputs = new[] { "buildTargetGroup", "defines", "serverAvailability" },
            RequiresInput = new[] { "defines" },
            MayTriggerReload = true, MutatesAssets = true)]
        public static object DebugSetDefines(string defines)
        {
            if (Validate.Required(defines, "defines") is object definesErr) return definesErr;

            if (WorkflowManager.IsRecording)
                WorkflowManager.SnapshotSetting("debug.scriptingDefines", CaptureDefinesValue(), "Debug: Scripting Define Symbols");

            var group = EditorUserBuildSettings.selectedBuildTargetGroup;
            try
            {
                PlayerSettings.SetScriptingDefineSymbols(NamedBuildTarget.FromBuildTargetGroup(group), defines);
            }
            catch (System.Exception ex)
            {
                return new
                {
                    success = false,
                    error = $"Failed to set scripting define symbols for {group}: {ex.Message}",
                    buildTargetGroup = group.ToString(),
                    defines
                };
            }

            return new
            {
                success = true,
                buildTargetGroup = group.ToString(),
                defines,
                serverAvailability = ServerAvailabilityHelper.CreateTransientUnavailableNotice(
                    "Scripting define symbols changed. Unity may recompile assemblies immediately.",
                    alwaysInclude: true)
            };
        }

        [UnitySkill("debug_get_memory_info", "Get memory usage information",
            Category = SkillCategory.Debug, Operation = SkillOperation.Query,
            Tags = new[] { "memory", "profiler", "usage", "heap" },
            Outputs = new[] { "totalAllocatedMB", "totalReservedMB", "monoUsedSizeMB", "monoHeapSizeMB" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object DebugGetMemoryInfo()
        {
            return new
            {
                success = true,
                totalAllocatedMB = UnityEngine.Profiling.Profiler.GetTotalAllocatedMemoryLong() / (1024.0 * 1024.0),
                totalReservedMB = UnityEngine.Profiling.Profiler.GetTotalReservedMemoryLong() / (1024.0 * 1024.0),
                totalUnusedReservedMB = UnityEngine.Profiling.Profiler.GetTotalUnusedReservedMemoryLong() / (1024.0 * 1024.0),
                monoUsedSizeMB = UnityEngine.Profiling.Profiler.GetMonoUsedSizeLong() / (1024.0 * 1024.0),
                monoHeapSizeMB = UnityEngine.Profiling.Profiler.GetMonoHeapSizeLong() / (1024.0 * 1024.0)
            };
        }
    }
}

// Producer:Betsy
