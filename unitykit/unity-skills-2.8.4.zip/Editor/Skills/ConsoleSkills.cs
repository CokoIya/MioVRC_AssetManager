﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace UnitySkills
{
    /// <summary>
    /// Skills related to the Console panel: log reading / capture / export and console toggles.
    /// </summary>
    public static class ConsoleSkills
    {
        private static readonly List<LogEntry> _logs = new List<LogEntry>();
        private static readonly object _logLock = new object();
        private static bool _capturing;

        // Console flag bitmasks; values match Unity's internal ConsoleWindow flags.
        private const int FlagClearOnPlay = 16;
        private const int FlagCollapse = 32;
        private const int FlagErrorPause = 256;

        /// <summary>
        /// Registers setting readers/writers so console flag changes can actually be rolled back via workflow undo/redo.
        /// Runs on domain load.
        /// </summary>
        [InitializeOnLoadMethod]
        private static void RegisterSettingRestorers()
        {
            WorkflowSettingRestorerRegistry.Register("console.pauseOnError",
                () => JsonConvert.SerializeObject(GetConsoleFlagValue(FlagErrorPause, "DeveloperMode_ErrorPause")),
                json => { ConsoleSetPauseOnError(JsonConvert.DeserializeObject<bool>(json)); return true; });

            WorkflowSettingRestorerRegistry.Register("console.collapse",
                () => JsonConvert.SerializeObject(GetConsoleFlagValue(FlagCollapse, "UnitySkills_Console_Collapse")),
                json => { ConsoleSetCollapse(JsonConvert.DeserializeObject<bool>(json)); return true; });

            WorkflowSettingRestorerRegistry.Register("console.clearOnPlay",
                () => JsonConvert.SerializeObject(GetConsoleFlagValue(FlagClearOnPlay, "UnitySkills_Console_ClearOnPlay")),
                json => { ConsoleSetClearOnPlay(JsonConvert.DeserializeObject<bool>(json)); return true; });
        }

        /// <summary>
        /// Reads the current state of a console flag. The data source matches the write path
        /// (ConsoleWindow's s_ConsoleFlags field); falls back to EditorPrefs if unavailable.
        /// </summary>
        private static bool GetConsoleFlagValue(int flag, string prefFallbackKey)
        {
            var consoleType = System.Type.GetType("UnityEditor.ConsoleWindow, UnityEditor");
            var flagField = consoleType?.GetField("s_ConsoleFlags", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);
            if (flagField != null)
            {
                int flags = (int)flagField.GetValue(null);
                return (flags & flag) != 0;
            }
            return EditorPrefs.GetBool(prefFallbackKey, false);
        }

        private class LogEntry
        {
            public string message;
            public string stackTrace;
            public LogType type;
            public System.DateTime time;
        }

        [UnitySkill("console_start_capture", "Start capturing console logs",
            Category = SkillCategory.Console, Operation = SkillOperation.Execute,
            Tags = new[] { "console", "capture", "logs", "start" },
            Outputs = new[] { "message" })]
        public static object ConsoleStartCapture()
        {
            if (!_capturing)
            {
                Application.logMessageReceived += OnLogMessage;
                _capturing = true;
            }
            lock (_logLock) { _logs.Clear(); }
            return new { success = true, message = "Console capture started" };
        }

        [UnitySkill("console_stop_capture", "Stop capturing console logs",
            Category = SkillCategory.Console, Operation = SkillOperation.Execute,
            Tags = new[] { "console", "capture", "logs", "stop" },
            Outputs = new[] { "message", "capturedCount" })]
        public static object ConsoleStopCapture()
        {
            if (_capturing)
            {
                Application.logMessageReceived -= OnLogMessage;
                _capturing = false;
            }
            int count;
            lock (_logLock) { count = _logs.Count; }
            return new { success = true, message = "Console capture stopped", capturedCount = count };
        }

        [UnitySkill("console_get_logs", "Get Unity Console logs. Reads existing console history directly (no setup needed). Use type=All/Error/Warning/Log to filter. When console_start_capture is active, returns captured logs with timestamps instead.",
            Category = SkillCategory.Console, Operation = SkillOperation.Query,
            Tags = new[] { "console", "logs", "filter", "errors" },
            Outputs = new[] { "count", "logs", "source" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object ConsoleGetLogs(string type = "All", string filter = null, int limit = 100)
        {
            if (_capturing)
            {
                // Capture mode: returns timestamped logs from the buffer.
                lock (_logLock)
                {
                    IEnumerable<LogEntry> results = _logs;
                    if (type != "All")
                        results = results.Where(l => CapturedLogMatchesType(l.type, type));
                    if (!string.IsNullOrEmpty(filter))
                        results = results.Where(l => l.message.Contains(filter));

                    var captured = results.TakeLast(limit).Select(l => new
                    {
                        type = l.type.ToString(),
                        message = l.message,
                        time = l.time.ToString("HH:mm:ss.fff")
                    }).ToArray();
                    return new { count = captured.Length, logs = captured, source = "capture" };
                }
            }

            // Direct-read mode: reads existing entries from Unity Console via reflection on LogEntries.
            int targetMask = 0;
            if (type == "All" || type.Contains("Error"))   targetMask |= DebugSkills.ErrorModeMask;
            if (type == "All" || type.Contains("Warning")) targetMask |= DebugSkills.WarningModeMask;
            if (type == "All" || type.Contains("Log"))     targetMask |= DebugSkills.LogModeMask;
            if (targetMask == 0) targetMask = DebugSkills.ErrorModeMask | DebugSkills.WarningModeMask | DebugSkills.LogModeMask;

            var logs = DebugSkills.ReadLogEntries(targetMask, filter, limit);
            return new { count = logs.Count, logs, source = "console" };
        }

        private static bool CapturedLogMatchesType(LogType logType, string typeFilter)
        {
            switch (typeFilter)
            {
                case "Error":   return logType == LogType.Error || logType == LogType.Exception || logType == LogType.Assert;
                case "Warning": return logType == LogType.Warning;
                case "Log":     return logType == LogType.Log;
                default:        return true;
            }
        }

        [UnitySkill("console_clear", "Clear the Unity console",
            Category = SkillCategory.Console, Operation = SkillOperation.Execute,
            Tags = new[] { "console", "clear", "logs" },
            Outputs = new[] { "message" })]
        public static object ConsoleClear()
        {
            var assembly = System.Reflection.Assembly.GetAssembly(typeof(SceneView));
            var logEntries = assembly.GetType("UnityEditor.LogEntries");
            var clearMethod = logEntries.GetMethod("Clear");
            clearMethod.Invoke(null, null);

            lock (_logLock) { _logs.Clear(); }
            return new { success = true, message = "Console cleared" };
        }

        [UnitySkill("console_log", "Write a message to the console",
            Category = SkillCategory.Console, Operation = SkillOperation.Execute,
            Tags = new[] { "console", "log", "debug", "message" },
            Outputs = new[] { "logged", "warning" },
            RequiresInput = new[] { "message" })]
        public static object ConsoleLog(string message, string type = "log")
        {
            string normalized = type?.ToLower() ?? "log";
            string warning = null;
            switch (normalized)
            {
                case "warning":
                    Debug.LogWarning(message);
                    break;
                case "error":
                    Debug.LogError(message);
                    break;
                case "log":
                    Debug.Log(message);
                    break;
                default:
                    // An unrecognized type (e.g. "Fatal") is still written out as Log on a best-effort basis, but must return a warning:
                    // silently downgrading would hide a misspelled or made-up value, letting the caller believe the type actually took effect.
                    warning = $"Unrecognized type '{type}'; valid values are Log, Warning, Error. Logged as Log.";
                    Debug.Log(message);
                    break;
            }
            return new { success = true, logged = message, warning };
        }

        private static void OnLogMessage(string message, string stackTrace, LogType type)
        {
            lock (_logLock)
            {
                _logs.Add(new LogEntry
                {
                    message = message,
                    stackTrace = stackTrace,
                    type = type,
                    time = System.DateTime.Now
                });

                // Keep only the most recent 1000 entries.
                if (_logs.Count > 1000)
                    _logs.RemoveAt(0);
            }
        }

        [UnitySkill("console_set_pause_on_error", "Enable or disable Error Pause in Play mode", TracksWorkflow = true,
            Category = SkillCategory.Console, Operation = SkillOperation.Modify,
            Tags = new[] { "console", "pause", "error", "playmode" },
            Outputs = new[] { "enabled" })]
        public static object ConsoleSetPauseOnError(bool enabled = true)
        {
            if (WorkflowManager.IsRecording)
                WorkflowManager.SnapshotSetting("console.pauseOnError",
                    JsonConvert.SerializeObject(GetConsoleFlagValue(FlagErrorPause, "DeveloperMode_ErrorPause")),
                    "Console: Error Pause");

            var consoleType = System.Type.GetType("UnityEditor.ConsoleWindow, UnityEditor");
            if (consoleType == null) return new { error = "ConsoleWindow not found" };
            var flagField = consoleType.GetField("s_ConsoleFlags", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);
            if (flagField == null) { EditorPrefs.SetBool("DeveloperMode_ErrorPause", enabled); return new { success = true, enabled, note = "Set via EditorPrefs" }; }
            int flags = (int)flagField.GetValue(null);
            flags = enabled ? flags | 256 : flags & ~256;
            flagField.SetValue(null, flags);
            return new { success = true, enabled };
        }

        [UnitySkill("console_export", "Export console logs to a file. Uses captured buffer when console_start_capture is active; otherwise reads directly from Unity Console history (no setup needed).",
            Category = SkillCategory.Console, Operation = SkillOperation.Execute,
            Tags = new[] { "console", "export", "file", "logs" },
            Outputs = new[] { "path", "count", "source" })]
        public static object ConsoleExport(string savePath = "Assets/console_log.txt")
        {
            if (Validate.SafePath(savePath, "savePath") is object pathErr) return pathErr;
            var dir = System.IO.Path.GetDirectoryName(savePath);
            if (!string.IsNullOrEmpty(dir) && !System.IO.Directory.Exists(dir)) System.IO.Directory.CreateDirectory(dir);

            // Only the capture branch reads _logs, so the condition must check only _capturing.
            // After console_stop_capture, _logs still retains entries from the previous capture round (this is intentional,
            // so that console_get_logs' branch — which is likewise gated on _capturing — won't see them either).
            // If this were changed to check _logs.Count > 0, it would forever export that stale snapshot.
            if (_capturing)
            {
                lock (_logLock)
                {
                    var lines = _logs.Select(l => $"[{l.time:HH:mm:ss.fff}] [{l.type}] {l.message}");
                    System.IO.File.WriteAllLines(savePath, lines);
                    return new { success = true, path = savePath, count = _logs.Count, source = "capture" };
                }
            }

            // Direct-read mode: reads Unity Console directly when there's no capture buffer.
            int allMask = DebugSkills.ErrorModeMask | DebugSkills.WarningModeMask | DebugSkills.LogModeMask;
            var entries = DebugSkills.ReadLogEntries(allMask, null, 1000);
            var directLines = entries.Select(e => { dynamic d = e; return $"[{d.type}] {d.message}"; });
            System.IO.File.WriteAllLines(savePath, directLines.Cast<string>());
            return new { success = true, path = savePath, count = entries.Count, source = "console" };
        }

        [UnitySkill("console_get_stats", "Get log statistics (count by type). Uses captured buffer when console_start_capture is active; otherwise reads directly from Unity Console history.",
            Category = SkillCategory.Console, Operation = SkillOperation.Query,
            Tags = new[] { "console", "stats", "count", "summary" },
            Outputs = new[] { "total", "logs", "warnings", "errors", "source" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object ConsoleGetStats()
        {
            // Same rule as console_export: after capture stops, _logs is just a leftover snapshot,
            // the condition must check only _capturing, otherwise it will keep reporting "source: capture".
            if (_capturing)
            {
                lock (_logLock)
                {
                    return new
                    {
                        success = true, total = _logs.Count, source = "capture",
                        logs = _logs.Count(l => l.type == LogType.Log),
                        warnings = _logs.Count(l => l.type == LogType.Warning),
                        errors = _logs.Count(l => l.type == LogType.Error),
                        exceptions = _logs.Count(l => l.type == LogType.Exception),
                        asserts = _logs.Count(l => l.type == LogType.Assert)
                    };
                }
            }

            // Direct-read mode: reads Unity Console directly.
            int allMask = DebugSkills.ErrorModeMask | DebugSkills.WarningModeMask | DebugSkills.LogModeMask;
            var entries = DebugSkills.ReadLogEntries(allMask, null, 10000);
            int errCount = 0, warnCount = 0, logCount = 0;
            foreach (dynamic e in entries)
            {
                switch ((string)e.type)
                {
                    case "Error":   errCount++;  break;
                    case "Warning": warnCount++; break;
                    default:        logCount++;  break;
                }
            }
            return new { success = true, total = entries.Count, source = "console", logs = logCount, warnings = warnCount, errors = errCount };
        }

        [UnitySkill("console_set_collapse", "Set console log collapse mode", TracksWorkflow = true,
            Category = SkillCategory.Console, Operation = SkillOperation.Modify,
            Tags = new[] { "console", "collapse", "settings" },
            Outputs = new[] { "setting", "enabled" })]
        public static object ConsoleSetCollapse(bool enabled)
        {
            if (WorkflowManager.IsRecording)
                WorkflowManager.SnapshotSetting("console.collapse",
                    JsonConvert.SerializeObject(GetConsoleFlagValue(FlagCollapse, "UnitySkills_Console_Collapse")),
                    "Console: Collapse");

            return SetConsoleFlag(FlagCollapse, enabled, "Collapse");
        }

        [UnitySkill("console_set_clear_on_play", "Set clear on play mode", TracksWorkflow = true,
            Category = SkillCategory.Console, Operation = SkillOperation.Modify,
            Tags = new[] { "console", "clear", "playmode", "settings" },
            Outputs = new[] { "setting", "enabled" })]
        public static object ConsoleSetClearOnPlay(bool enabled)
        {
            if (WorkflowManager.IsRecording)
                WorkflowManager.SnapshotSetting("console.clearOnPlay",
                    JsonConvert.SerializeObject(GetConsoleFlagValue(FlagClearOnPlay, "UnitySkills_Console_ClearOnPlay")),
                    "Console: Clear On Play");

            return SetConsoleFlag(FlagClearOnPlay, enabled, "ClearOnPlay");
        }

        private static object SetConsoleFlag(int flag, bool enabled, string name)
        {
            var consoleType = System.Type.GetType("UnityEditor.ConsoleWindow, UnityEditor");
            if (consoleType == null) return new { error = "ConsoleWindow not found" };

            // Unity 6+: prefer the ConsoleWindow.SetConsoleFlag method.
            var setFlagMethod = consoleType.GetMethod("SetConsoleFlag", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public);
            if (setFlagMethod != null)
            {
                try { setFlagMethod.Invoke(null, new object[] { flag, enabled }); return new { success = true, setting = name, enabled }; }
                catch { /* fall through */ }
            }

            // Older versions: modify the s_ConsoleFlags field directly.
            var flagField = consoleType.GetField("s_ConsoleFlags", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic);
            if (flagField != null)
            {
                int flags = (int)flagField.GetValue(null);
                flags = enabled ? flags | flag : flags & ~flag;
                flagField.SetValue(null, flags);
                return new { success = true, setting = name, enabled };
            }

            // Fall back further: the LogEntries API.
            var logEntriesType = System.Type.GetType("UnityEditor.LogEntries, UnityEditor");
            if (logEntriesType != null)
            {
                var setMethod = logEntriesType.GetMethod("SetConsoleFlag", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic);
                if (setMethod != null)
                {
                    try { setMethod.Invoke(null, new object[] { flag, enabled }); return new { success = true, setting = name, enabled }; }
                    catch { /* fall through */ }
                }
            }

            // Last resort: write to EditorPrefs only.
            EditorPrefs.SetBool("UnitySkills_Console_" + name, enabled);
            return new { success = true, setting = name, enabled, note = "Set via EditorPrefs fallback" };
        }
    }
}

// Producer:Betsy
