﻿using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace UnitySkills
{
    /// <summary>
    /// Animator management skills: create controllers, manage parameters, control playback.
    /// </summary>
    public static class AnimatorSkills
    {
        [UnitySkill("animator_create_controller", "Create a new Animator Controller",
            Category = SkillCategory.Animator, Operation = SkillOperation.Create,
            Tags = new[] { "animator", "controller", "create", "animation" },
            Outputs = new[] { "success", "name", "path" },
            RequiresInput = new[] { "name" },
            MutatesAssets = true)]
        public static object AnimatorCreateController(string name, string folder = "Assets/Animations")
        {
            if (Validate.Required(name, "name") is object nameErr) return nameErr;
            if (name.Contains("/") || name.Contains("\\") || name.Contains(".."))
                return new { error = "name must not contain path separators" };

            var folderErr = Validate.SafePath(folder, "folder");
            if (folderErr != null) return folderErr;

            if (!Directory.Exists(folder))
                Directory.CreateDirectory(folder);

            var path = Path.Combine(folder, name + ".controller");
            if (File.Exists(path))
                return new { error = $"Controller already exists: {path}" };

            var controller = AnimatorController.CreateAnimatorControllerAtPath(path);
            WorkflowManager.SnapshotObject(controller, SnapshotType.Created);
            AssetDatabase.SaveAssets();

            return new { success = true, name, path };
        }

        [UnitySkill("animator_add_parameter", "Add a parameter to an Animator Controller",
            Category = SkillCategory.Animator, Operation = SkillOperation.Modify,
            Tags = new[] { "animator", "parameter", "add", "controller" },
            Outputs = new[] { "success", "controller", "parameter", "type" },
            RequiresInput = new[] { "controllerPath" },
            MutatesAssets = true)]
        public static object AnimatorAddParameter(string controllerPath, string paramName, string paramType = "float", float defaultFloat = 0, int defaultInt = 0, bool defaultBool = false)
        {
            var pathErr = Validate.SafePath(controllerPath, "controllerPath");
            if (pathErr != null) return pathErr;
            if (Validate.Required(paramName, "paramName") is object paramNameErr) return paramNameErr;

            var controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath);
            if (controller == null)
                return new { error = $"Controller not found: {controllerPath}" };

            AnimatorControllerParameterType type;
            switch (paramType.ToLower())
            {
                case "float":
                    type = AnimatorControllerParameterType.Float;
                    break;
                case "int":
                    type = AnimatorControllerParameterType.Int;
                    break;
                case "bool":
                    type = AnimatorControllerParameterType.Bool;
                    break;
                case "trigger":
                    type = AnimatorControllerParameterType.Trigger;
                    break;
                default:
                    return new { error = $"Unknown parameter type: {paramType}. Use: float, int, bool, trigger" };
            }

            WorkflowManager.SnapshotObject(controller);
            controller.AddParameter(paramName, type);

            // AnimatorControllerParameter is a value type, so the array element must be mutated in
            // place by index and written back wholesale; mutating a copy pulled out of the enumeration has no effect.
            var parameters = controller.parameters;
            int idx = System.Array.FindIndex(parameters, p => p.name == paramName);
            if (idx >= 0)
            {
                switch (type)
                {
                    case AnimatorControllerParameterType.Float:
                        parameters[idx].defaultFloat = defaultFloat;
                        break;
                    case AnimatorControllerParameterType.Int:
                        parameters[idx].defaultInt = defaultInt;
                        break;
                    case AnimatorControllerParameterType.Bool:
                        parameters[idx].defaultBool = defaultBool;
                        break;
                    default: break;
                }
                controller.parameters = parameters;
            }

            EditorUtility.SetDirty(controller);
            AssetDatabase.SaveAssets();

            return new { success = true, controller = controllerPath, parameter = paramName, type = paramType };
        }

        [UnitySkill("animator_get_parameters", "Get all parameters from an Animator Controller",
            Category = SkillCategory.Animator, Operation = SkillOperation.Query,
            Tags = new[] { "animator", "parameter", "list", "controller" },
            Outputs = new[] { "controller", "parameters" },
            RequiresInput = new[] { "controllerPath" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object AnimatorGetParameters(string controllerPath)
        {
            var pathErr = Validate.SafePath(controllerPath, "controllerPath");
            if (pathErr != null) return pathErr;

            var controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath);
            if (controller == null)
                return new { error = $"Controller not found: {controllerPath}" };

            var parameters = controller.parameters.Select(p => new
            {
                name = p.name,
                type = p.type.ToString(),
                defaultFloat = p.defaultFloat,
                defaultInt = p.defaultInt,
                defaultBool = p.defaultBool
            }).ToArray();

            return new { controller = controllerPath, parameters };
        }

        [UnitySkill("animator_set_parameter", "Set a parameter value on a GameObject's Animator (supports name/instanceId/path)",
            Category = SkillCategory.Animator, Operation = SkillOperation.Modify,
            Tags = new[] { "animator", "parameter", "set", "value" },
            Outputs = new[] { "success", "gameObject", "parameter", "value" },
            RequiresInput = new[] { "gameObject" },
            MutatesScene = true)]
        public static object AnimatorSetParameter(
            string name = null, int instanceId = 0, string path = null,
            string paramName = null, string paramType = "float",
            float floatValue = 0, int intValue = 0, bool boolValue = false)
        {
            if (Validate.Required(paramName, "paramName") is object err) return err;

            var (animator, error) = GameObjectFinder.FindComponentOrError<Animator>(name, instanceId, path);
            if (error != null) return error;

            if (animator.runtimeAnimatorController == null)
                return new
                {
                    error = $"GameObject '{animator.gameObject.name}' has an Animator but no AnimatorController assigned",
                    errorCode = SkillErrorCode.TargetNotFound.ToWireString()
                };

            // Animator.SetFloat/SetInteger/SetBool/SetTrigger fail silently on a parameter name
            // that doesn't exist (no exception, no log), so the runtime parameter table must be
            // checked first, otherwise a misspelled paramName would be reported as a success.
            var parameters = animator.parameters;
            var matchedParam = parameters.FirstOrDefault(p => p.name == paramName);
            bool paramExists = parameters.Any(p => p.name == paramName);
            if (!paramExists)
            {
                return new
                {
                    error = $"Parameter '{paramName}' not found on Animator '{animator.gameObject.name}'",
                    errorCode = SkillErrorCode.TargetNotFound.ToWireString(),
                    availableParameters = parameters.Select(p => new { name = p.name, type = p.type.ToString() }).ToArray()
                };
            }

            var requestedType = (paramType ?? "float").ToLower();
            bool typeMatches = requestedType switch
            {
                "float" => matchedParam.type == AnimatorControllerParameterType.Float,
                "int" => matchedParam.type == AnimatorControllerParameterType.Int,
                "bool" => matchedParam.type == AnimatorControllerParameterType.Bool,
                "trigger" => matchedParam.type == AnimatorControllerParameterType.Trigger,
                _ => false
            };
            if (!typeMatches)
            {
                return new
                {
                    error = $"Parameter '{paramName}' is of type {matchedParam.type} on the controller, but paramType='{paramType}' was requested",
                    errorCode = SkillErrorCode.SemanticInvalid.ToWireString()
                };
            }

            WorkflowManager.SnapshotObject(animator);
            Undo.RecordObject(animator, "Set Animator Parameter");

            switch (requestedType)
            {
                case "float":
                    animator.SetFloat(paramName, floatValue);
                    return new { success = true, gameObject = animator.gameObject.name, parameter = paramName, value = floatValue };
                case "int":
                    animator.SetInteger(paramName, intValue);
                    return new { success = true, gameObject = animator.gameObject.name, parameter = paramName, value = intValue };
                case "bool":
                    animator.SetBool(paramName, boolValue);
                    return new { success = true, gameObject = animator.gameObject.name, parameter = paramName, value = boolValue };
                case "trigger":
                    animator.SetTrigger(paramName);
                    return new { success = true, gameObject = animator.gameObject.name, parameter = paramName, triggered = true };
                default:
                    return new { error = $"Unknown parameter type: {paramType}" };
            }
        }

        [UnitySkill("animator_play", "Play an animation state on a GameObject (supports name/instanceId/path)",
            Category = SkillCategory.Animator, Operation = SkillOperation.Execute,
            Tags = new[] { "animator", "play", "state", "animation" },
            Outputs = new[] { "success", "gameObject", "state", "layer" },
            RequiresInput = new[] { "gameObject" })]
        public static object AnimatorPlay(string name = null, int instanceId = 0, string path = null, string stateName = null, int layer = 0, float normalizedTime = 0)
        {
            if (Validate.Required(stateName, "stateName") is object err1) return err1;

            var (animator, error) = GameObjectFinder.FindComponentOrError<Animator>(name, instanceId, path);
            if (error != null) return error;

            // Animator.Play likewise fails silently on a state name that doesn't exist, so the state
            // machine (including sub-state machines) is walked recursively to validate first, so a misspelled stateName isn't reported as a successful play.
            var controller = animator.runtimeAnimatorController as AnimatorController;
            if (controller == null && animator.runtimeAnimatorController != null)
            {
                var controllerAssetPath = AssetDatabase.GetAssetPath(animator.runtimeAnimatorController);
                if (!string.IsNullOrEmpty(controllerAssetPath))
                    controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerAssetPath);
            }

            if (controller == null)
                return new
                {
                    error = $"GameObject '{animator.gameObject.name}' has an Animator but no AnimatorController assigned",
                    errorCode = SkillErrorCode.TargetNotFound.ToWireString()
                };

            if (layer < 0 || layer >= controller.layers.Length)
                return new
                {
                    error = $"Layer {layer} does not exist. Controller has {controller.layers.Length} layers.",
                    errorCode = SkillErrorCode.SemanticInvalid.ToWireString()
                };

            var availableStates = new List<string>();
            if (!SearchStateMachineForState(controller.layers[layer].stateMachine, "", stateName, availableStates))
            {
                return new
                {
                    error = $"State '{stateName}' not found on layer {layer} of controller",
                    errorCode = SkillErrorCode.TargetNotFound.ToWireString(),
                    availableStates = availableStates.ToArray()
                };
            }

            animator.Play(stateName, layer, normalizedTime);

            return new { success = true, gameObject = animator.gameObject.name, state = stateName, layer };
        }

        /// <summary>
        /// Collects the names of all reachable states in <paramref name="stateMachine"/> (dotted
        /// paths for sub-state machines) into <paramref name="names"/>, and returns whether
        /// <paramref name="target"/> matches a state's simple name or its full dotted path.
        /// </summary>
        private static bool SearchStateMachineForState(AnimatorStateMachine stateMachine, string prefix, string target, List<string> names)
        {
            bool found = false;
            foreach (var s in stateMachine.states)
            {
                var fullName = prefix + s.state.name;
                names.Add(fullName);
                if (s.state.name == target || fullName == target) found = true;
            }
            foreach (var child in stateMachine.stateMachines)
            {
                var childPrefix = prefix + child.stateMachine.name + ".";
                if (SearchStateMachineForState(child.stateMachine, childPrefix, target, names)) found = true;
            }
            return found;
        }

        [UnitySkill("animator_get_info", "Get Animator component information (supports name/instanceId/path)",
            Category = SkillCategory.Animator, Operation = SkillOperation.Query,
            Tags = new[] { "animator", "info", "inspect", "controller" },
            Outputs = new[] { "gameObject", "instanceId", "hasController", "controllerPath", "speed", "layerCount", "parameterCount" },
            RequiresInput = new[] { "gameObject" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object AnimatorGetInfo(string name = null, int instanceId = 0, string path = null)
        {
            var (animator, error) = GameObjectFinder.FindComponentOrError<Animator>(name, instanceId, path);
            if (error != null) return error;

            var controllerPath = animator.runtimeAnimatorController != null
                ? AssetDatabase.GetAssetPath(animator.runtimeAnimatorController)
                : null;

            return new
            {
                gameObject = animator.gameObject.name,
                entityId = UnityObjectIdUtility.GetEntityId(animator.gameObject),
                instanceId = UnityObjectIdUtility.GetObjectId(animator.gameObject),
                hasController = animator.runtimeAnimatorController != null,
                controllerPath,
                speed = animator.speed,
                applyRootMotion = animator.applyRootMotion,
                updateMode = animator.updateMode.ToString(),
                cullingMode = animator.cullingMode.ToString(),
                layerCount = animator.layerCount,
                parameterCount = animator.parameterCount
            };
        }

        [UnitySkill("animator_assign_controller", "Assign an Animator Controller to a GameObject (supports name/instanceId/path)",
            Category = SkillCategory.Animator, Operation = SkillOperation.Modify,
            Tags = new[] { "animator", "controller", "assign", "bind" },
            Outputs = new[] { "success", "gameObject", "controller" },
            RequiresInput = new[] { "gameObject", "controllerPath" },
            MutatesScene = true)]
        public static object AnimatorAssignController(string name = null, int instanceId = 0, string path = null, string controllerPath = null)
        {
            if (Validate.Required(controllerPath, "controllerPath") is object err2) return err2;
            var pathErr = Validate.SafePath(controllerPath, "controllerPath");
            if (pathErr != null) return pathErr;

            var (go, error) = GameObjectFinder.FindOrError(name, instanceId, path);
            if (error != null) return error;

            var animator = go.GetComponent<Animator>();
            if (animator == null)
            {
                animator = Undo.AddComponent<Animator>(go);
                WorkflowManager.SnapshotCreatedComponent(animator);
            }

            var controller = AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(controllerPath);
            if (controller == null)
                return new { error = $"Controller not found: {controllerPath}" };

            Undo.RecordObject(animator, "Assign Animator Controller");
            animator.runtimeAnimatorController = controller;

            return new { success = true, gameObject = go.name, controller = controllerPath };
        }

        [UnitySkill("animator_list_states", "List all states in an Animator Controller layer",
            Category = SkillCategory.Animator, Operation = SkillOperation.Query,
            Tags = new[] { "animator", "state", "list", "layer" },
            Outputs = new[] { "controller", "layer", "layerName", "stateCount", "states" },
            RequiresInput = new[] { "controllerPath" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object AnimatorListStates(string controllerPath, int layer = 0)
        {
            var pathErr = Validate.SafePath(controllerPath, "controllerPath");
            if (pathErr != null) return pathErr;

            var controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath);
            if (controller == null)
                return new { error = $"Controller not found: {controllerPath}" };

            if (layer >= controller.layers.Length)
                return new { error = $"Layer {layer} does not exist. Controller has {controller.layers.Length} layers." };

            var stateMachine = controller.layers[layer].stateMachine;
            var states = stateMachine.states.Select(s => new
            {
                name = s.state.name,
                tag = s.state.tag,
                speed = s.state.speed,
                hasMotion = s.state.motion != null
            }).ToArray();

            return new
            {
                controller = controllerPath,
                layer,
                layerName = controller.layers[layer].name,
                stateCount = states.Length,
                states
            };
        }
        [UnitySkill("animator_add_state", "Add a state to an Animator Controller layer",
            Category = SkillCategory.Animator, Operation = SkillOperation.Create | SkillOperation.Modify,
            Tags = new[] { "animator", "state", "add", "layer" },
            Outputs = new[] { "success", "controller", "stateName", "layer" },
            RequiresInput = new[] { "controllerPath" },
            TracksWorkflow = true,
            MutatesAssets = true)]
        public static object AnimatorAddState(string controllerPath, string stateName, string clipPath = null, int layer = 0)
        {
            var controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath);
            if (controller == null) return new { error = $"Controller not found: {controllerPath}" };
            if (layer < 0 || layer >= controller.layers.Length) return new { error = $"Invalid layer: {layer}" };

            var sm = controller.layers[layer].stateMachine;
            var state = sm.AddState(stateName);
            if (!string.IsNullOrEmpty(clipPath))
            {
                var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(clipPath);
                if (clip != null) state.motion = clip;
            }
            AssetDatabase.SaveAssets();
            return new { success = true, controller = controllerPath, stateName, layer };
        }

        [UnitySkill("animator_add_transition", "Add a transition between two states in an Animator Controller",
            Category = SkillCategory.Animator, Operation = SkillOperation.Create | SkillOperation.Modify,
            Tags = new[] { "animator", "transition", "state", "flow" },
            Outputs = new[] { "success", "from", "to", "layer", "hasExitTime", "duration" },
            RequiresInput = new[] { "controllerPath" },
            TracksWorkflow = true,
            MutatesAssets = true)]
        public static object AnimatorAddTransition(string controllerPath, string fromState, string toState, int layer = 0, bool hasExitTime = true, float duration = 0.25f)
        {
            var controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath);
            if (controller == null) return new { error = $"Controller not found: {controllerPath}" };
            if (layer < 0 || layer >= controller.layers.Length) return new { error = $"Invalid layer: {layer}" };

            var sm = controller.layers[layer].stateMachine;
            var states = sm.states;
            AnimatorState src = null, dst = null;
            foreach (var s in states)
            {
                if (s.state.name == fromState) src = s.state;
                if (s.state.name == toState) dst = s.state;
            }
            if (src == null) return new { error = $"State not found: {fromState}" };
            if (dst == null) return new { error = $"State not found: {toState}" };

            var transition = src.AddTransition(dst);
            transition.hasExitTime = hasExitTime;
            transition.duration = duration;
            AssetDatabase.SaveAssets();
            return new { success = true, from = fromState, to = toState, layer, hasExitTime, duration };
        }
    }
}

// Producer:Betsy
