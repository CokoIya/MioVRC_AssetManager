﻿using UnityEngine;
using UnityEditor;
using System.Linq;
using System.Collections.Generic;
using UnitySkills.Internal;

namespace UnitySkills
{
    /// <summary>
    /// Audio import settings skills: read/write AudioImporter properties.
    /// </summary>
    public static class AudioSkills
    {
        [UnitySkill("audio_get_settings", "Get audio import settings for an audio asset",
            Category = SkillCategory.Audio, Operation = SkillOperation.Query,
            Tags = new[] { "audio", "import", "settings", "clip" },
            Outputs = new[] { "path", "forceToMono", "loadType", "compressionFormat", "quality" },
            RequiresInput = new[] { "assetPath" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object AudioGetSettings(string assetPath)
        {
            if (Validate.Required(assetPath, "assetPath") is object err) return err;

            var importer = AssetImporter.GetAtPath(assetPath) as AudioImporter;
            if (importer == null)
                return new { error = $"Not an audio file or asset not found: {assetPath}" };

            var defaultSettings = importer.defaultSampleSettings;

            return new
            {
                success = true,
                path = assetPath,
                forceToMono = importer.forceToMono,
                loadInBackground = importer.loadInBackground,
                ambisonic = importer.ambisonic,
                loadType = defaultSettings.loadType.ToString(),
                compressionFormat = defaultSettings.compressionFormat.ToString(),
                quality = defaultSettings.quality,
                sampleRateSetting = defaultSettings.sampleRateSetting.ToString()
            };
        }

        [UnitySkill("audio_set_settings", "Set audio import settings. loadType: DecompressOnLoad/CompressedInMemory/Streaming. compressionFormat: PCM/Vorbis/ADPCM. quality: 0.0-1.0",
            Category = SkillCategory.Audio, Operation = SkillOperation.Modify,
            Tags = new[] { "audio", "import", "settings", "compression", "quality" },
            Outputs = new[] { "success", "path", "changesApplied", "changes" },
            RequiresInput = new[] { "assetPath" },
            MutatesAssets = true)]
        public static object AudioSetSettings(
            string assetPath,
            bool? forceToMono = null,
            bool? loadInBackground = null,
            bool? ambisonic = null,
            string loadType = null,
            string compressionFormat = null,
            float? quality = null,
            string sampleRateSetting = null)
        {
            if (Validate.Required(assetPath, "assetPath") is object err) return err;

            var importer = AssetImporter.GetAtPath(assetPath) as AudioImporter;
            if (importer == null)
                return new { error = $"Not an audio file or asset not found: {assetPath}" };

            // All three enums must be fully parsed before the first assignment, otherwise an error
            // would leave forceToMono/loadInBackground/ambisonic already written to the importer.
            if (!SkillParamUtil.TryParseOptionalEnum<AudioClipLoadType>(loadType, "loadType", out var lt, out var ltError))
                return ltError;
            if (!SkillParamUtil.TryParseOptionalEnum<AudioCompressionFormat>(compressionFormat, "compressionFormat", out var cf, out var cfError))
                return cfError;
            if (!SkillParamUtil.TryParseOptionalEnum<AudioSampleRateSetting>(sampleRateSetting, "sampleRateSetting", out var srs, out var srsError))
                return srsError;

            var changes = new List<string>();

            if (forceToMono.HasValue)
            {
                importer.forceToMono = forceToMono.Value;
                changes.Add($"forceToMono={forceToMono.Value}");
            }

            if (loadInBackground.HasValue)
            {
                importer.loadInBackground = loadInBackground.Value;
                changes.Add($"loadInBackground={loadInBackground.Value}");
            }

            if (ambisonic.HasValue)
            {
                importer.ambisonic = ambisonic.Value;
                changes.Add($"ambisonic={ambisonic.Value}");
            }

            var sampleSettings = importer.defaultSampleSettings;
            bool sampleSettingsChanged = false;

            if (lt.HasValue)
            {
                sampleSettings.loadType = lt.Value;
                changes.Add($"loadType={lt.Value}");
                sampleSettingsChanged = true;
            }

            if (cf.HasValue)
            {
                sampleSettings.compressionFormat = cf.Value;
                changes.Add($"compressionFormat={cf.Value}");
                sampleSettingsChanged = true;
            }

            if (quality.HasValue)
            {
                sampleSettings.quality = Mathf.Clamp01(quality.Value);
                changes.Add($"quality={SkillParamUtil.FormatFloatR(sampleSettings.quality)}");
                sampleSettingsChanged = true;
            }

            if (srs.HasValue)
            {
                sampleSettings.sampleRateSetting = srs.Value;
                changes.Add($"sampleRateSetting={srs.Value}");
                sampleSettingsChanged = true;
            }

            if (sampleSettingsChanged)
            {
                importer.defaultSampleSettings = sampleSettings;
            }

            importer.SaveAndReimport();

            return new
            {
                success = true,
                path = assetPath,
                changesApplied = changes.Count,
                changes
            };
        }

        [UnitySkill("audio_set_settings_batch", "Set audio import settings for multiple audio files. items: JSON array of {assetPath, forceToMono, loadType, compressionFormat, quality, ...}",
            Category = SkillCategory.Audio, Operation = SkillOperation.Modify,
            Tags = new[] { "audio", "import", "batch", "settings", "bulk" },
            Outputs = new[] { "totalItems", "successCount", "results" },
            RequiresInput = new[] { "items" },
            MutatesAssets = true)]
        public static object AudioSetSettingsBatch(string items)
        {
            return BatchExecutor.Execute<BatchAudioItem>(items, item =>
            {
                var importer = AssetImporter.GetAtPath(item.assetPath) as AudioImporter;
                if (importer == null)
                    throw new System.Exception("Not an audio file");

                // Parse before writing any property, and attach the failing item's assetPath,
                // so a misspelled enum entry isn't reported as a success.
                if (!SkillParamUtil.TryParseOptionalEnum<AudioClipLoadType>(item.loadType, "loadType", out var lt, out _))
                    return SkillParamUtil.InvalidEnumError<AudioClipLoadType>(item.loadType, "loadType", item.assetPath);
                if (!SkillParamUtil.TryParseOptionalEnum<AudioCompressionFormat>(item.compressionFormat, "compressionFormat", out var cf, out _))
                    return SkillParamUtil.InvalidEnumError<AudioCompressionFormat>(item.compressionFormat, "compressionFormat", item.assetPath);

                if (item.forceToMono.HasValue)
                    importer.forceToMono = item.forceToMono.Value;
                if (item.loadInBackground.HasValue)
                    importer.loadInBackground = item.loadInBackground.Value;

                var ss = importer.defaultSampleSettings;
                bool ssChanged = false;

                if (lt.HasValue) { ss.loadType = lt.Value; ssChanged = true; }
                if (cf.HasValue) { ss.compressionFormat = cf.Value; ssChanged = true; }

                if (item.quality.HasValue)
                { ss.quality = Mathf.Clamp01(item.quality.Value); ssChanged = true; }

                if (ssChanged)
                    importer.defaultSampleSettings = ss;

                importer.SaveAndReimport();
                return new { path = item.assetPath, success = true };
            }, item => item.assetPath);
        }

        private class BatchAudioItem
        {
            public string assetPath { get; set; }
            public bool? forceToMono { get; set; }
            public bool? loadInBackground { get; set; }
            public string loadType { get; set; }
            public string compressionFormat { get; set; }
            public float? quality { get; set; }
        }

        [UnitySkill("audio_find_clips", "Search for AudioClip assets in the project",
            Category = SkillCategory.Audio, Operation = SkillOperation.Query,
            Tags = new[] { "audio", "clip", "search", "find", "asset" },
            Outputs = new[] { "totalFound", "showing", "clips" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object AudioFindClips(string filter = "", int limit = 50)
        {
            var guids = AssetDatabase.FindAssets("t:AudioClip " + filter);
            var clips = guids.Take(limit).Select(guid =>
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var clip = AssetDatabase.LoadAssetAtPath<AudioClip>(path);
                return new { path, name = clip != null ? clip.name : System.IO.Path.GetFileNameWithoutExtension(path), length = clip != null ? clip.length : 0f };
            }).ToArray();
            return new { success = true, totalFound = guids.Length, showing = clips.Length, clips };
        }

        [UnitySkill("audio_get_clip_info", "Get detailed information about an AudioClip asset",
            Category = SkillCategory.Audio, Operation = SkillOperation.Query,
            Tags = new[] { "audio", "clip", "info", "inspect" },
            Outputs = new[] { "name", "path", "length", "channels", "frequency", "samples", "loadType" },
            RequiresInput = new[] { "assetPath" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object AudioGetClipInfo(string assetPath)
        {
            if (Validate.Required(assetPath, "assetPath") is object err) return err;
            var clip = AssetDatabase.LoadAssetAtPath<AudioClip>(assetPath);
            if (clip == null) return new { error = $"AudioClip not found: {assetPath}" };

            return new { success = true, name = clip.name, path = assetPath, length = clip.length, channels = clip.channels,
                frequency = clip.frequency, samples = clip.samples, loadType = clip.loadType.ToString(),
                loadState = clip.loadState.ToString(), ambisonic = clip.ambisonic };
        }

        [UnitySkill("audio_add_source", "Add an AudioSource component to a GameObject",
            Category = SkillCategory.Audio, Operation = SkillOperation.Create | SkillOperation.Modify,
            Tags = new[] { "audio", "source", "add", "component", "playback" },
            Outputs = new[] { "success", "gameObject", "instanceId" },
            RequiresInput = new[] { "gameObject" },
            TracksWorkflow = true, MutatesScene = true)]
        public static object AudioAddSource(string name = null, int instanceId = 0, string path = null, string clipPath = null, bool playOnAwake = false, bool loop = false, float volume = 1f)
        {
            var (go, error) = GameObjectFinder.FindOrError(name, instanceId, path);
            if (error != null) return error;

            // If clipPath is given but doesn't resolve, this must be rejected before AddComponent: otherwise
            // the component would already be added (a real side effect) while clip is silently dropped, and
            // the caller has no way to tell that playback is actually silent.
            // Consistent with every other setter in this repo: if the target doesn't resolve, reject the whole
            // call rather than applying it partially.
            AudioClip clip = null;
            if (!string.IsNullOrEmpty(clipPath))
            {
                clip = AssetDatabase.LoadAssetAtPath<AudioClip>(clipPath);
                if (clip == null)
                    return new
                    {
                        error = $"AudioClip not found: {clipPath}",
                        errorCode = SkillErrorCode.TargetNotFound.ToWireString()
                    };
            }

            var source = Undo.AddComponent<AudioSource>(go);
            source.playOnAwake = playOnAwake;
            source.loop = loop;
            source.volume = volume;
            if (clip != null) source.clip = clip;

            return new { success = true, gameObject = go.name, entityId = UnityObjectIdUtility.GetEntityId(go), instanceId = UnityObjectIdUtility.GetObjectId(go) };
        }

        [UnitySkill("audio_get_source_info", "Get AudioSource configuration",
            Category = SkillCategory.Audio, Operation = SkillOperation.Query,
            Tags = new[] { "audio", "source", "info", "inspect" },
            Outputs = new[] { "gameObject", "clip", "volume", "pitch", "loop", "spatialBlend" },
            RequiresInput = new[] { "gameObject" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object AudioGetSourceInfo(string name = null, int instanceId = 0, string path = null)
        {
            var (source, error) = GameObjectFinder.FindComponentOrError<AudioSource>(name, instanceId, path);
            if (error != null) return error;

            return new { success = true, gameObject = source.gameObject.name, clip = source.clip != null ? source.clip.name : "null",
                volume = source.volume, pitch = source.pitch, loop = source.loop, playOnAwake = source.playOnAwake,
                mute = source.mute, spatialBlend = source.spatialBlend, minDistance = source.minDistance,
                maxDistance = source.maxDistance, priority = source.priority };
        }

        [UnitySkill("audio_set_source_properties", "Set AudioSource properties",
            Category = SkillCategory.Audio, Operation = SkillOperation.Modify,
            Tags = new[] { "audio", "source", "property", "volume", "pitch" },
            Outputs = new[] { "success", "gameObject" },
            RequiresInput = new[] { "gameObject" },
            TracksWorkflow = true, MutatesScene = true)]
        public static object AudioSetSourceProperties(string name = null, int instanceId = 0, string path = null, string clipPath = null,
            float? volume = null, float? pitch = null, bool? loop = null, bool? playOnAwake = null, bool? mute = null, float? spatialBlend = null, int? priority = null)
        {
            var (source, error) = GameObjectFinder.FindComponentOrError<AudioSource>(name, instanceId, path);
            if (error != null) return error;

            Undo.RecordObject(source, "Set AudioSource Properties");
            if (!string.IsNullOrEmpty(clipPath)) { var clip = AssetDatabase.LoadAssetAtPath<AudioClip>(clipPath); if (clip != null) source.clip = clip; }
            if (volume.HasValue) source.volume = volume.Value;
            if (pitch.HasValue) source.pitch = pitch.Value;
            if (loop.HasValue) source.loop = loop.Value;
            if (playOnAwake.HasValue) source.playOnAwake = playOnAwake.Value;
            if (mute.HasValue) source.mute = mute.Value;
            if (spatialBlend.HasValue) source.spatialBlend = spatialBlend.Value;
            if (priority.HasValue) source.priority = priority.Value;

            return new { success = true, gameObject = source.gameObject.name };
        }

        [UnitySkill("audio_find_sources_in_scene", "Find all AudioSource components in the current scene",
            Category = SkillCategory.Audio, Operation = SkillOperation.Query,
            Tags = new[] { "audio", "source", "find", "scene", "search" },
            Outputs = new[] { "totalFound", "showing", "sources" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object AudioFindSourcesInScene(int limit = 50)
        {
            var sources = FindHelper.FindAll<AudioSource>();
            var results = sources.Take(limit).Select(s => new { gameObject = s.gameObject.name, path = GameObjectFinder.GetPath(s.gameObject),
                clip = s.clip != null ? s.clip.name : "null", volume = s.volume, loop = s.loop, enabled = s.enabled }).ToArray();
            return new { success = true, totalFound = sources.Length, showing = results.Length, sources = results };
        }

        [UnitySkill("audio_create_mixer", "Create a new AudioMixer asset",
            Category = SkillCategory.Audio, Operation = SkillOperation.Create,
            Tags = new[] { "audio", "mixer", "create", "asset" },
            Outputs = new[] { "success", "path", "name" },
            TracksWorkflow = true, MutatesAssets = true)]
        public static object AudioCreateMixer(string mixerName = "NewAudioMixer", string folder = "Assets")
        {
            if (Validate.Required(mixerName, "mixerName") is object nameErr) return nameErr;
            if (mixerName.Contains("/") || mixerName.Contains("\\") || mixerName.Contains(".."))
                return new { error = "mixerName must not contain path separators" };
            if (Validate.SafePath(folder, "folder") is object pathErr) return pathErr;
            if (!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);

            var savePath = System.IO.Path.Combine(folder, mixerName + ".mixer").Replace("\\", "/");
            if (System.IO.File.Exists(savePath)) return new { error = $"Mixer already exists: {savePath}" };

            // The assembly AudioMixerController lives in varies by Unity version, so we have to scan all assemblies for it.
            System.Type mixerType = null;
            foreach (var asm in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                mixerType = asm.GetType("UnityEditor.Audio.AudioMixerController");
                if (mixerType != null) break;
            }
            if (mixerType == null) return new { error = "AudioMixerController type not found" };

            // CreateMixerControllerAtPath is the official internal factory method; prefer it.
            var createMethod = mixerType.GetMethod("CreateMixerControllerAtPath",
                System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic);
            if (createMethod != null)
            {
                var result = createMethod.Invoke(null, new object[] { savePath });
                if (result != null)
                {
                    AssetDatabase.SaveAssets();
                    return new { success = true, path = savePath, name = mixerName };
                }
            }

            // Fallback: create the instance directly (may log a warning on Unity 6).
            var mixer = ScriptableObject.CreateInstance(mixerType);
            if (mixer != null)
            {
                mixer.name = mixerName;
                AssetDatabase.CreateAsset(mixer, savePath);
                AssetDatabase.SaveAssets();
                return new { success = true, path = savePath, name = mixerName };
            }

            return new { error = "Failed to create AudioMixer. Use Assets > Create > Audio > Audio Mixer." };
        }
    }
}

// Producer:Betsy
