﻿using UnityEngine;
using UnityEngine.AI;
using UnityEditor;
using UnityEditor.AI;

namespace UnitySkills
{
    /// <summary>
    /// NavMesh skills: baking and pathfinding.
    /// </summary>
    public static class NavMeshSkills
    {
        [UnitySkill("navmesh_bake", "Bake the NavMesh (Synchronous). Warning: blocks the Editor, can be slow on large scenes.",
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Execute,
            Tags = new[] { "navmesh", "bake", "pathfinding", "navigation" },
            Outputs = new[] { "success", "message" },
            LongRunning = true, MutatesScene = true)]
        public static object NavMeshBake()
        {
            // CS0618 exemption: UnityEditor.AI.NavMeshBuilder is still the only entry point for a global editor
            // bake; the recommended replacement UnityEngine.AI.NavMeshBuilder is a runtime incremental-build API
            // (not equivalent), and componentized NavMeshSurface requires taking a dependency on the AI
            // Navigation package — both are out of scope for this skill's semantics.
#pragma warning disable 0618
            UnityEditor.AI.NavMeshBuilder.BuildNavMesh();
#pragma warning restore 0618
            return new { success = true, message = "NavMesh baked successfully" };
        }

        [UnitySkill("navmesh_clear", "Clear the NavMesh data",
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Delete,
            Tags = new[] { "navmesh", "clear", "navigation" },
            Outputs = new[] { "success", "warning" },
            MutatesScene = true, RiskLevel = "high")]
        public static object NavMeshClear()
        {
            // CS0618 exemption: same as NavMeshBake — the legacy API is the only equivalent entry point for a global clear.
#pragma warning disable 0618
            UnityEditor.AI.NavMeshBuilder.ClearAllNavMeshes();
#pragma warning restore 0618
            return new { success = true, warning = "NavMesh cleared. This operation cannot be undone." };
        }

        [UnitySkill("navmesh_calculate_path", "Calculate a path between two points. Returns: {status, distance, cornerCount, corners}",
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Query,
            Tags = new[] { "navmesh", "path", "pathfinding", "navigation" },
            Outputs = new[] { "status", "valid", "distance", "cornerCount", "corners" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object NavMeshCalculatePath(
            float startX, float startY, float startZ,
            float endX, float endY, float endZ,
            int areaMask = NavMesh.AllAreas
        )
        {
            var startPos = new Vector3(startX, startY, startZ);
            var endPos = new Vector3(endX, endY, endZ);
            
            NavMeshPath path = new NavMeshPath();
            bool hasPath = NavMesh.CalculatePath(startPos, endPos, areaMask, path);
            
            if (!hasPath)
                return new { status = "NoPath", valid = false };
            
            float distance = 0f;
            if (path.status == NavMeshPathStatus.PathComplete || path.status == NavMeshPathStatus.PathPartial)
            {
                for (int i = 0; i < path.corners.Length - 1; i++)
                    distance += Vector3.Distance(path.corners[i], path.corners[i + 1]);
            }
            
            var corners = new System.Collections.Generic.List<object>();
            foreach(var c in path.corners)
            {
                corners.Add(new { x = c.x, y = c.y, z = c.z });
            }

            return new
            {
                status = path.status.ToString(),
                valid = path.status == NavMeshPathStatus.PathComplete,
                distance,
                cornerCount = path.corners.Length,
                corners
            };
        }

        [UnitySkill("navmesh_add_agent", "Add NavMeshAgent component to an object", TracksWorkflow = true,
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Create,
            Tags = new[] { "navmesh", "agent", "component", "navigation" },
            Outputs = new[] { "success", "gameObject" },
            RequiresInput = new[] { "gameObject" }, MutatesScene = true)]
        public static object NavMeshAddAgent(string name = null, int instanceId = 0, string path = null)
        {
            var (go, err) = GameObjectFinder.FindOrError(name, instanceId, path);
            if (err != null) return err;
            if (go.GetComponent<NavMeshAgent>() != null) return new { error = $"{go.name} already has NavMeshAgent" };
            Undo.AddComponent<NavMeshAgent>(go);
            WorkflowManager.SnapshotObject(go, SnapshotType.Created);
            return new { success = true, gameObject = go.name };
        }

        [UnitySkill("navmesh_set_agent", "Set NavMeshAgent properties (speed, acceleration, radius, height, stoppingDistance)", TracksWorkflow = true,
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Modify,
            Tags = new[] { "navmesh", "agent", "speed", "properties" },
            Outputs = new[] { "success", "gameObject", "speed", "radius" },
            RequiresInput = new[] { "gameObject" }, MutatesScene = true)]
        public static object NavMeshSetAgent(string name = null, int instanceId = 0, string path = null,
            float? speed = null, float? acceleration = null, float? angularSpeed = null,
            float? radius = null, float? height = null, float? stoppingDistance = null)
        {
            var (go, err) = GameObjectFinder.FindOrError(name, instanceId, path);
            if (err != null) return err;
            var agent = go.GetComponent<NavMeshAgent>();
            if (agent == null) return new { error = $"No NavMeshAgent on {go.name}" };
            WorkflowManager.SnapshotObject(agent);
            Undo.RecordObject(agent, "Set NavMeshAgent");
            if (speed.HasValue) agent.speed = speed.Value;
            if (acceleration.HasValue) agent.acceleration = acceleration.Value;
            if (angularSpeed.HasValue) agent.angularSpeed = angularSpeed.Value;
            if (radius.HasValue) agent.radius = radius.Value;
            if (height.HasValue) agent.height = height.Value;
            if (stoppingDistance.HasValue) agent.stoppingDistance = stoppingDistance.Value;
            return new { success = true, gameObject = go.name, speed = agent.speed, radius = agent.radius };
        }

        [UnitySkill("navmesh_add_obstacle", "Add NavMeshObstacle component to an object", TracksWorkflow = true,
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Create,
            Tags = new[] { "navmesh", "obstacle", "component", "carving" },
            Outputs = new[] { "success", "gameObject", "carving" },
            RequiresInput = new[] { "gameObject" }, MutatesScene = true)]
        public static object NavMeshAddObstacle(string name = null, int instanceId = 0, string path = null, bool carve = true)
        {
            var (go, err) = GameObjectFinder.FindOrError(name, instanceId, path);
            if (err != null) return err;
            if (go.GetComponent<NavMeshObstacle>() != null) return new { error = $"{go.name} already has NavMeshObstacle" };
            var obs = Undo.AddComponent<NavMeshObstacle>(go);
            obs.carving = carve;
            WorkflowManager.SnapshotObject(go, SnapshotType.Created);
            return new { success = true, gameObject = go.name, carving = obs.carving };
        }

        [UnitySkill("navmesh_set_obstacle", "Set NavMeshObstacle properties (shape, size, carving)", TracksWorkflow = true,
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Modify,
            Tags = new[] { "navmesh", "obstacle", "shape", "carving" },
            Outputs = new[] { "success", "gameObject", "shape", "carving" },
            RequiresInput = new[] { "gameObject" }, MutatesScene = true)]
        public static object NavMeshSetObstacle(string name = null, int instanceId = 0, string path = null,
            string shape = null, float? sizeX = null, float? sizeY = null, float? sizeZ = null, bool? carving = null)
        {
            var (go, err) = GameObjectFinder.FindOrError(name, instanceId, path);
            if (err != null) return err;
            var obs = go.GetComponent<NavMeshObstacle>();
            if (obs == null) return new { error = $"No NavMeshObstacle on {go.name}" };

            // Must resolve before any write: otherwise an invalid shape would be silently dropped while
            // size/carving in the same call still get written, and the response would still report success.
            if (!SkillParamUtil.TryParseOptionalEnum<NavMeshObstacleShape>(shape, "shape", out var s, out var shapeError))
                return shapeError;

            WorkflowManager.SnapshotObject(obs);
            Undo.RecordObject(obs, "Set NavMeshObstacle");
            if (s.HasValue) obs.shape = s.Value;
            if (sizeX.HasValue || sizeY.HasValue || sizeZ.HasValue)
            {
                var sz = obs.size;
                obs.size = new Vector3(sizeX ?? sz.x, sizeY ?? sz.y, sizeZ ?? sz.z);
            }
            if (carving.HasValue) obs.carving = carving.Value;
            return new { success = true, gameObject = go.name, shape = obs.shape.ToString(), carving = obs.carving };
        }

        [UnitySkill("navmesh_sample_position", "Find nearest point on NavMesh",
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Query,
            Tags = new[] { "navmesh", "sample", "nearest", "position" },
            Outputs = new[] { "success", "found", "point", "distance" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object NavMeshSamplePosition(float x, float y, float z, float maxDistance = 10f)
        {
            var sourcePos = new Vector3(x, y, z);
            if (NavMesh.SamplePosition(sourcePos, out NavMeshHit hit, maxDistance, NavMesh.AllAreas))
                return new { success = true, found = true, point = new { x = hit.position.x, y = hit.position.y, z = hit.position.z }, distance = hit.distance };
            return new { success = true, found = false };
        }

        [UnitySkill("navmesh_set_area_cost", "Set area traversal cost",
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Modify,
            Tags = new[] { "navmesh", "area", "cost", "traversal" },
            Outputs = new[] { "success", "areaIndex", "cost" })]
        public static object NavMeshSetAreaCost(int areaIndex, float cost)
        {
            if (Validate.InRange(areaIndex, 0, 31, "areaIndex") is object err1) return err1;
            if (cost < 0) return new { error = "cost must be >= 0" };
            NavMesh.SetAreaCost(areaIndex, cost);
            return new { success = true, areaIndex, cost };
        }

        [UnitySkill("navmesh_get_settings", "Get NavMesh build settings",
            Category = SkillCategory.NavMesh, Operation = SkillOperation.Query,
            Tags = new[] { "navmesh", "settings", "agent", "build" },
            Outputs = new[] { "success", "agentRadius", "agentHeight", "agentSlope", "agentClimb" },
            ReadOnly = true,
            Mode = SkillMode.SemiAuto)]
        public static object NavMeshGetSettings()
        {
            var settings = NavMesh.GetSettingsByIndex(0);
            return new
            {
                success = true, agentRadius = settings.agentRadius, agentHeight = settings.agentHeight,
                agentSlope = settings.agentSlope, agentClimb = settings.agentClimb
            };
        }
    }
}

// Producer:Betsy
