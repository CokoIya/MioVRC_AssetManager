---
name: unity-importer
description: Configure asset import settings
---

> **Before calling any skill in this module:** if you are about to call a skill with parameters guessed from its name or description, STOP — read this file (or fetch its schema via `GET /skills/recommend?includeSchema=true`) first. If you already have the parameter definitions from recommend/schema, you may proceed straight to dryRun.

## Triggers
- Adjusting how assets import
- Setting texture compression or sprite modes
- Applying per-platform overrides
- 调整资源导入方式、设置贴图压缩或 Sprite 模式、应用分平台覆盖

# Unity Importer Skills

Use this module to change import **settings** for textures, audio, and models that already exist in the project.

> **Batch-first**: Prefer the batch setters when configuring `2+` assets of the same category.

## Guardrails

**Operating Mode** (v1.9 three-tier):
- **Approval** (default): query/getter skills (`texture_get_settings`, `texture_get_info`, `texture_find_assets`, `texture_find_by_size`, `texture_get_platform_settings`, `texture_get_import_settings`, `audio_get_settings`, `audio_get_clip_info`, `audio_find_clips`, `audio_find_sources_in_scene`, `audio_get_source_info`, `audio_get_import_settings`, `model_get_settings`, `model_find_assets`, `model_get_mesh_info`, `model_get_materials_info`, `model_get_animations_info`, `model_get_rig_info`, `model_get_import_settings`, `asset_get_labels`) run directly. Setters / reimport are FullAuto — on `MODE_RESTRICTED`, run the grant protocol.
- **Auto** / **Bypass**: SemiAuto and FullAuto run directly.
- This module contains **no** Delete / PlayMode / Reload / `RiskLevel="high"` skills — nothing auto-classifies as forbidden. Importer mutations are reachable via grant in Approval mode.
- Setting changes do not always apply in memory immediately; call `asset_reimport` / `asset_reimport_batch` when Unity needs to fully refresh the asset.

**DO NOT** (common hallucinations):
- `importer_import` does not exist -> use `asset_import` in the `asset` module to bring files into the project
- `importer_set_format` does not exist -> use the specific texture/audio/model setters
- `importer_get_settings` does not exist -> use the category-specific getters
- Settings changes do not always apply instantly in memory. Reimport may still be required

**Routing**:
- File import or refresh -> `asset`
- Texture settings -> `texture_*`
- Audio settings -> `audio_*`
- Model settings -> `model_*`
- Alternative importer bridge skills -> `texture_set_import_settings`, `audio_set_import_settings`, `model_set_import_settings`
- Force importer refresh -> `asset_reimport` or `asset_reimport_batch`

## Skills

### Texture Route

Import settings:

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `texture_get_settings` | Read texture importer settings | `assetPath` |
| `texture_set_settings` | Set texture importer settings | `assetPath`, `textureType?`, `maxSize?`, `filterMode?`, `compression?`, `mipmapEnabled?`, `sRGB?`, `readable?`, `wrapMode?` |
| `texture_set_settings_batch` | Batch texture settings | `items` |
| `texture_get_import_settings` | Read minimal importer settings (type/maxSize/compression/filter/srgb/readable/mipmap) | `assetPath` |
| `texture_set_import_settings` | Alternative texture import bridge | similar texture fields |

> **`compression` vocabulary.** Pass the CLR member names of `TextureImporterCompression` — `Uncompressed`, `Compressed`, `CompressedHQ`, `CompressedLQ` — which are also what the getters echo back. The Inspector's wording is accepted as aliases: `None` → `Uncompressed`, `Normal` and `NormalQuality` → `Compressed`, `LowQuality` → `CompressedLQ`, `HighQuality` → `CompressedHQ`; spaces are stripped first, so `"Low Quality"` and `"High Quality"` also work. `texture_set_settings` and `texture_set_import_settings` share this one vocabulary — they used to disagree, so a value that works on one now works on the other. Per-platform `compressionQuality` is a separate `0-100` integer, not this enum. Full field list → [IMPORT_REFERENCE.md](IMPORT_REFERENCE.md).

Query and runtime info:

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `texture_find_assets` | Search Texture2D assets by AssetDatabase filter | `filter?`, `limit?` (default 50) |
| `texture_get_info` | Inspect dimensions, format, and runtime memory size | `assetPath` |
| `texture_find_by_size` | Find textures in a dimension range (pixels) | `minSize?` (0), `maxSize?` (99999), `limit?` (50) |

Typed / platform overrides:

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `texture_set_type` | Switch texture type | `assetPath`, `textureType` (`Default`/`NormalMap`/`GUI`/`Sprite`/`Cursor`/`Cookie`/`Lightmap`/`SingleChannel`/`Shadowmask`/`DirectionalLightmap`; `EditorGUI` aliases `GUI`, and Inspector labels like `"Normal Map"` work as-is) |
| `texture_set_platform_settings` | Override per-platform settings | `assetPath`, `platform` (`Standalone`/`iPhone`/`Android`/`WebGL`), `maxSize?`, `format?` (accepted set is editor-version dependent — take it from `validValues` on a rejection), `compressionQuality?`, `overridden?` |
| `texture_get_platform_settings` | Read per-platform override | `assetPath`, `platform` |
| `texture_set_sprite_settings` | Sprite-specific knobs (PPU, mode) | `assetPath`, `pixelsPerUnit?`, `spriteMode?` (`None`/`Single`/`Multiple`/`Polygon`) |
| `sprite_set_import_settings` | Sprite importer bridge (PPU, packingTag, pivot) | `assetPath`, `spriteMode?` (same four values), `pixelsPerUnit?`, `packingTag?`, `pivotX?`, `pivotY?` |

> **`spriteMode` is the plain `SpriteImportMode` vocabulary — all four members, `None` included.** The two skills differ in what they do around it: `sprite_set_import_settings` forces `textureType` to `Sprite` for `Single`/`Multiple`/`Polygon` and deliberately leaves the texture type alone for `None` (a Sprite-typed texture with no sprite is unusable), and it echoes the resulting `textureType` back. `texture_set_sprite_settings` only writes the mode and pixels-per-unit.

Common texture decisions:
- UI sprites -> `textureType="Sprite"`, usually `mipmapEnabled=false`
- Pixel art -> `filterMode="Point"`
- Runtime CPU reads -> `readable=true` only when necessary
- Platform-tuned builds -> prefer `texture_set_platform_settings` over global `texture_set_settings`

### Audio Route

Import settings:

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `audio_get_settings` | Read audio importer settings | `assetPath` |
| `audio_set_settings` | Set audio importer settings | `assetPath`, `forceToMono?`, `loadInBackground?`, `loadType?`, `compressionFormat?`, `quality?` |
| `audio_set_settings_batch` | Batch audio settings | `items` |
| `audio_get_import_settings` | Read minimal importer defaults (loadType/format/quality/forceToMono/loadInBackground) | `assetPath` |
| `audio_set_import_settings` | Alternative audio import bridge | similar audio fields |

Clip query and info:

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `audio_find_clips` | Search `AudioClip` assets by filter | `filter?`, `limit?` (default 50) |
| `audio_get_clip_info` | Inspect length/channels/frequency/samples of a clip | `assetPath` |

Scene runtime (`AudioSource` / `AudioMixer`):

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `audio_add_source` | Add an `AudioSource` to a GameObject | target (`name`/`instanceId`/`path`), `clipPath?`, `playOnAwake?` (false), `loop?` (false), `volume?` (1) |
| `audio_get_source_info` | Read the AudioSource configuration | target |
| `audio_set_source_properties` | Update AudioSource fields | target, `clipPath?`, `volume?`, `pitch?`, `loop?`, `playOnAwake?`, `mute?`, `spatialBlend?`, `priority?` |
| `audio_find_sources_in_scene` | List all AudioSources in the active scene | `limit?` (default 50) |
| `audio_create_mixer` | Create a new `AudioMixer` asset | `mixerName?` (default `NewAudioMixer`), `folder?` (default `Assets`) |

Common audio decisions:
- Long BGM -> `loadType="Streaming"`
- Short SFX -> `loadType="DecompressOnLoad"`
- Memory-sensitive SFX libraries -> consider `forceToMono=true`
- Scene-side AudioSource tuning -> prefer `audio_set_source_properties` over manual component edits

### Model Route

Import settings:

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `model_get_settings` | Read model importer settings | `assetPath` |
| `model_set_settings` | Set model importer settings | `assetPath`, `globalScale?`, `meshCompression?`, `isReadable?`, `generateSecondaryUV?`, `animationType?`, `importAnimation?`, `importCameras?`, `importLights?`, `materialImportMode?` |
| `model_set_settings_batch` | Batch model settings | `items` |
| `model_get_import_settings` | Read minimal importer defaults (scale/compression/animationType/importAnimation/materialImportMode) | `assetPath` |
| `model_set_import_settings` | Alternative model import bridge | similar model fields |

Query and info:

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `model_find_assets` | Search model assets by filter | `filter?`, `limit?` (default 50) |
| `model_get_mesh_info` | Mesh vertex / triangle / submesh stats | target (`name`/`instanceId`/`path`) or `assetPath` |
| `model_get_materials_info` | Inspect sub-asset materials embedded in the model | `assetPath` |
| `model_get_animations_info` | List animation clips and framerates on the model | `assetPath` |
| `model_get_rig_info` | Read animationType, avatar, skeleton binding info | `assetPath` |

Animation and rig:

| Skill | Use | Key parameters |
|-------|-----|----------------|
| `model_set_animation_clips` | Configure animation clip splits | `assetPath`, `clips` (JSON array of `{name, firstFrame, lastFrame, loop}`) |
| `model_set_rig` | Switch rig/skeleton mode | `assetPath`, `animationType` (`None`/`Legacy`/`Generic`/`Human`), `avatarSetup?` |

> `animationType` rig mode: the CLR enum member is `Human` — `Humanoid` is the Inspector's label for it and is accepted as an alias, so either spelling works. `model_get_rig_info` echoes the CLR name (`Human`) and also returns `isHuman`.

Common model decisions:
- Characters -> `animationType="Human"` (or the `Humanoid` alias) when retargeting is required
- Static props -> disable cameras/lights/animation imports when unused
- Baked-lighting meshes -> enable secondary UVs when appropriate
- After `model_set_rig` or `model_set_animation_clips` -> call `asset_reimport` to refresh clips and avatar

## Reimport Rule

After importer changes, use reimport when you need Unity to fully refresh the asset:

| Skill | Use |
|-------|-----|
| `asset_reimport` | Reimport one asset |
| `asset_reimport_batch` | Reimport assets matching a search scope |

## Minimal Example

```python
import unity_skills

unity_skills.call_skill("texture_set_settings_batch", items=[
    {"assetPath": "Assets/UI/icon_play.png", "textureType": "Sprite", "mipmapEnabled": False},
    {"assetPath": "Assets/UI/icon_pause.png", "textureType": "Sprite", "mipmapEnabled": False}
])

unity_skills.call_skill("audio_set_settings",
    assetPath="Assets/Audio/bgm.mp3",
    loadType="Streaming",
    compressionFormat="Vorbis",
    quality=0.7
)

unity_skills.call_skill("asset_reimport", assetPath="Assets/Audio/bgm.mp3")
```

## Exact Signatures

Exact names, parameters, defaults, and returns are defined by `GET /skills/schema` or `unity_skills.get_skill_schema()`, not by this file.
Load `IMPORT_REFERENCE.md` for extended asset search/query helpers, platform overrides, rig/animation details, and importer-side best practices.
